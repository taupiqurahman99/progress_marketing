<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    function __construct()
    {
        parent::__construct();
         if($this->session->userdata("id_user") == "") {
            redirect('Login');
        }
         $this->load->library('session');
        $this->load->model('Model_crud');
        $this->load->library('form_validation');
    }
    public function index()
    {
       $data['cust'] = $this->Model_crud->get_data();
       $data["jumlahCustomer"] = $this->Model_crud->jumlahCustomer();
       $data["jumlahCancel"] = $this->Model_crud->jumlahCancel();
       $data["jumlahClosing"] = $this->Model_crud->jumlahClosing();
         $data["jumlahProduk"] = $this->Model_crud->jumlahProduk();
            $data["jumlahVendor"] = $this->Model_crud->jumlahVendor();
             $data["charts"] = $this->Model_crud->grafik();
    
 

       $this->load->view('admin/navbar');
       $this->load->view('admin/sidebar');
       $this->load->view('admin/halaman_dashboard', $data);
       $this->load->view('admin/footer');
   }

   public function customer_progress()
   {

    $data['customer'] = $this->Model_crud->get_data();
     $data['cs'] = $this->Model_crud->show_customer();

    $this->load->view('admin/navbar');
    $this->load->view('admin/sidebar');
    $this->load->view('admin/halaman_customer', $data);
    $this->load->view('admin/footer');
}

public function crud_konten()
{
    $this->Model_crud->createdata();
    $this->session->set_flashdata('sukses','berhasil');
    redirect(site_url('Admin/index'));
}


public function belapengadaan()
{
      $data['bela'] = $this->Model_crud->get_data1();
      

    $this->load->view('admin/navbar');
    $this->load->view('admin/sidebar');
    $this->load->view('admin/halaman_belapengadaan', $data);
    $this->load->view('admin/footer');
}

public function bela()
{
    $this->Model_crud->createdata1();
    $this->session->set_flashdata('sukses','berhasil');
    redirect(site_url('Admin/index'));
}

public function ads()
{
    $this->load->view('admin/navbar');
    $this->load->view('admin/sidebar');
    $this->load->view('admin/halaman_ads');
    $this->load->view('admin/footer');
}

   function edit_progress(){
       $id_customer = $this->input->post('id_customer');
                $nama_customer=$this->input->post('nama_customer');
                $status=$this->input->post('status');
                $this->Model_crud->edit_data($id_customer,$nama_customer,$status);
                
                
            
    $this->session->set_flashdata('sukses','berhasil');
    redirect(site_url('Admin/customer_progress'));
        }

public function logout()
    {
        //hapus session
        $this->session->sess_destroy();

        redirect('Login');
    }

}
