<?php
defined('BASEPATH') or exit ('No Direct Script Access Allowed');

class model_crud extends CI_Model{

  private $_table2 = "customer";
  private $_table3 = "belapengadaan";

  public function createdata()
  {
   $data = array 
   (
     'id_customer' =>  $this->input->post('id_customer'),
     'nama_customer' => $this->input->post('nama_customer'),
     'daerah' => $this->input->post('daerah'),
     'status' => $this->input->post('status'),
     'sumber_informasi' => $this->input->post('sumber_informasi'),
     'keterangan' => $this->input->post('keterangan'),
   );

   $this->db->insert('customer', $data);
 }
 
 public function edit_data12()
  {
   $data = array 
   (
     'id_customer' =>  $this->input->post('id_customer'),
     'nama_customer' => $this->input->post('nama_customer'),
     'status' => $this->input->post('status'),
    );

   $this->db->insert('customer', $data);
 }
 
 function edit_data($id_customer,$nama_customer,$status){
                $hasil=$this->db->query("UPDATE customer SET id_customer='$id_customer',nama_customer='$nama_customer',status='$status' WHERE id_customer='$id_customer'");
                return $hsl;
        }


 public function createdata1()
 {
   $data = array 
   (
     'id_vendor' =>  $this->input->post('id_vendor'),
     'nama_perusahaan' => $this->input->post('nama_perusahaan'),
     'website' => $this->input->post('website'),
     'jumlah_produk' => $this->input->post('jumlah_produk'),
     'jenis_produk' => $this->input->post('jenis_produk'),
   );

   $this->db->insert('belapengadaan', $data);
 }

 

 public function get_data()
 {
  return $this->db->get('customer')->result_array();
}

public function get_data1()
{
  return $this->db->get('belapengadaan')->result_array();
}

public function jumlahVendor()
{
  $this->db->select("count(id_vendor) as id_vendor");
  $this->db->from($this->_table3);
  return $this->db->get()->row()->id_vendor;
}

public function jumlahProduk()
{
$this->db->select("SUM(jumlah_produk) as total");
$this->db->from("belapengadaan");
return $this->db->get()->row()->total;
}

public function jumlahCustomer()
{
  $this->db->select("count(id_customer) as id_customer");
  $this->db->from($this->_table2);
  return $this->db->get()->row()->id_customer;
}

public function jumlahCancel()
{
  $this->db->select("count(status) as status");
  $this->db->from($this->_table2);
  $this->db->where('status',"batal");
  return $this->db->get()->row()->status;
}

public function jumlahClosing()
{
  $this->db->select("count(status) as status");
  $this->db->from($this->_table2);
  $this->db->where('status',"closing");
  return $this->db->get()->row()->status;
}

  public function grafik()
    {
        $query = "SELECT status AS GRAFIK, COUNT(*) AS total_grafik FROM customer
                    GROUP BY status";
        $result = $this->db->query($query)->result();
        return $result;
    }
    
     function show_customer()
     {
                $hasil=$this->db->query("SELECT * FROM customer");
                return $hasil;
        }




}