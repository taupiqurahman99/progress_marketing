<?php
defined('BASEPATH') or exit ('No Direct Script Access Allowed');

class M_user extends CI_Model
{


   public function simpan_register($data) {

        return $this->db->insert("user", $data);

    }
    // fungsi cek login
function cek_login($email, $password)
{
  $this->db->select("*");
  $this->db->where("email", $email);
  $this->db->from("user");
 
  $query = $this->db->get();
  $user = $query->row();

  /**
   * Check password
   */
   if (($user)) {

      if (password_verify($password, $user->password)) {

          return $query->result();

      } else {

          return FALSE;

      }

    } else {

       return FALSE;

    }
}
 

}