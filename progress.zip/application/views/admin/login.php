<!doctype html>
<html lang="notranslate">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

  <title>Login Akun</title>
</head>
<body>

  <div class="container" style="margin-top: 50px">
    <div class="row">
      <div class="col-md-4 offset-md-4">
        <div class="card">
          <div class="card-body">
            <center>
              <img src="<?php echo base_url();?>marketing.png" width="220">
            </center>
            <hr>

            <div class="form-group">
              <label>Email</label>
              <input type="text" id="email" class="form-control"  placeholder="Masukkan Username">
            </div>

            <div class="form-group">
              <label>Password</label>
              <input type="password" id="password" class="form-control" placeholder="Masukkan Password">
            </div>

            <button class="btn btn-login btn-block btn-success">LOGIN</button>

          </div>
        </div>
        <br>
        <center><footer>Copyright &copy; 2023 Marketing progress</footer></center>



      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" ></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.all.min.js"></script>

  <script>
    $(document).ready(function() {

      $(".btn-login").click( function() {

        var email = $("#email").val();
        var password = $("#password").val();

        if(email.length == "") {

          Swal.fire({
            type: 'warning',
            title: 'Oops...',
            text: 'Email Wajib Diisi !'
          });

        } else if(password.length == "") {

          Swal.fire({
            type: 'warning',
            title: 'Oops...',
            text: 'Password Wajib Diisi !'
          });

        } else {

          $.ajax({

            url: "<?php echo base_url();?>Login/cek_login",
            type: "POST",
            data: {
              "email": email,
              "password": password
            },

            success:function(response){

              if (response == "success") {

                Swal.fire({
                  type: 'success',
                  title: 'Login Berhasil!',
                  text: 'Anda akan di arahkan dalam 3 Detik',
                  timer: 3000,
                  showCancelButton: false,
                  showConfirmButton: false
                })
                .then (function() {
                  window.location.href = "<?php echo base_url();?>Admin";
                });

              } else {

                Swal.fire({
                  type: 'error',
                  title: 'Login Gagal!',
                  text: 'silahkan coba lagi!'
                });

              }

              console.log(response);

            },

            error:function(response){

              Swal.fire({
                type: 'error',
                title: 'Opps!',
                text: 'server error!'
              });

              console.log(response);

            }

          });

        }

      });

    });
  </script>

</body>
</html>