 <div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <div class="sb-sidenav-menu-heading">Web App</div>
                    <li <?=$this->uri->segment(2) == 'index'  || $this->uri->segment(1) == '' ? 'class="nav-link active"' : ''?>>
                        <a class="nav-link" href="<?php echo base_url();?>Admin/index">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt fa-1x"></i><span style="font-size:17px;">&nbsp;Dashboard</span></div>
                        </a>
                    </li>
                    <li <?=$this->uri->segment(2) == 'customer_progress' ? 'class="nav-link active"' : ''?>>
                        <a class="nav-link" href="<?php echo base_url();?>Admin/customer_progress">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i><span style="font-size:16px;">&nbsp;Customer Progress</span></div>
                        </a>
                    </li>
                     <li <?=$this->uri->segment(2) == 'ads' ? 'class="nav-link active"' : ''?>>
                        <a class="nav-link" href="<?php echo base_url();?>Admin/ads">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i><span style="font-size:16px;">&nbsp;Ads</span></div>
                        </a>
                    </li>
                    <!-- <li <?=$this->uri->segment(2) == 'belapengadaan' ? 'class="nav-link active"' : ''?>>
                        <a class="nav-link" href="<?php echo base_url();?>Admin/belapengadaan">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Bela Pengadaan
                        </a>
                    </li>  -->  
                </div>
            </div>
            <div class="text-center">
               <h1 class="mt-4"><img src="<?php echo base_url();?>marketing.png" width="90%"></h1>
           </div>

           <div class="sb-sidenav-footer">
            <div class="small">Admin</div>
            Progress akses gate
        </div>
    </nav>
</div>