           <div id="layoutSidenav_content">
            <main>
              <div class="container-fluid px-4">
                <h1 class="mt-4">Dashboard</h1>
             <?php if ($this->session->flashdata('sukses')): ?>
                  <script> Swal.fire(
                    'Success',
                    'Data berhasil disimpan',
                    'success'
                  );</script>
                <?php endif; ?>
                <div class="card mb-4">
                  <div class="card-header">
                    <i class="fas fa-chart-bar me-1"></i>
                    Progress akses gate
                  </div>

                  <div class="row">
                    <div class="col-xl-3 col-md-4">
                      <div class="card bg-primary text-white mb-4">
                       <center> <div class="card-body"><i class="fas fa-tasks fa-3x"></i><br>&nbsp;Customer progress</div></center>
                        <div class="card-footer bg-secondary d-flex align-items-center justify-content-between">
                          <h7 class="text-white stretched-link" href="#">Jumlah : <?php echo $jumlahCustomer ?></h1>
                          <h1 class="small text-white" href="#"></h1>
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-3 col-md-4">
                      <div class="card text-white mb-4" style="background-color: #FFA500;">
                       <center><div class="card-body"><i class="fas fa-shopping-cart fa-3x"></i><br>&nbsp;Ads</div></center> 
                        <div class="card-footer bg-secondary d-flex align-items-center justify-content-between">
                          <h7 class="text-white stretched-link" href="#">Jumlah : </h1>
                          <h1 class="small text-white" href="#"></h1>
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                      <div class="card bg-success text-white mb-4">
                        <center><div class="card-body"><i class="fas fa-clipboard-list fa-3x"></i><br>&nbsp;Closing</div></center>
                        <div class="card-footer bg-secondary d-flex align-items-center justify-content-between">
                          <h7 class="text-white stretched-link" href="#">Jumlah : <?php echo $jumlahClosing ?></h1>
                          <h1 class="small text-white" href="#"></h1>
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                      <div class="card text-white mb-4" style="background-color: red;">
                        <center><div class="card-body"><i class="fas fa-ban fa-3x"></i><br>&nbsp;Cancel</div></center>
                        <div class="card-footer bg-secondary d-flex align-items-center justify-content-between">
                          <h7 class="text-white stretched-link" href="#">Jumlah : <?php echo $jumlahCancel ?></h1></b>
                          <h1 class="small text-white" href="#"></h7>
                        </div>
                      </div>
                      
                  
                    </div>
                  </div>
                </div>
                
                   <div class="card mb-4">
                  <div class="card-header">
                    <i class="fas fa-chart-bar me-1"></i>
                    Grafik akses gate
                  </div>
                  <div class="row">
                       <canvas id="myChart"></canvas>
        <?php
        $grafik = "";            // string kosong untuk menampung data tahun
        $total_grafik = null;    // nilai awal null untuk menampung data total siswa
    

        // looping data dari $chartSiswa
        foreach ($charts as $chart) {
            $dataStatus     = "Grafik " . $chart->GRAFIK;
            $grafik       .= "'$dataStatus'" . ",";
            $dataTotal     = $chart->total_grafik;
            $total_grafik .= "'$dataTotal'" . ",";
        }

        ?>
               <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
<script type="text/javascript">
    const charts = document.getElementById('myChart').getContext('2d');
    const chart = new Chart(charts, {
        type: 'pie',
        data: {
            labels: [<?= $grafik; ?>], // data tahun sebagai label dari chart
            datasets: [{
                label: 'Jumlah Customer',
                backgroundColor: ['rgb(255, 99, 132)', 'rgba(56, 86, 255, 0.87)', 'rgb(60, 179, 113)', 'rgb(175, 238, 239)'],
                borderColor: ['rgb(255, 99, 132)'],
                data: [<?= $total_grafik; ?>] //data siswa sebagai data dari chart
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
</script>
                  </div>

                    
              
                <!-- <div class="card mb-4">
                  <div class="card-header">
                    <i class="fas fa-store"></i>
                  &nbsp;Bela Pengadaan
                  </div>
                  <div class="row">
                    <div class="col-xl-6 col-md-6">
                      <div class="card text-white mb-4" style="background-color: #008080;">
                        <center><div class="card-body"><i class="fas fa-building fa-3x"></i><br>&nbsp;Vendor</div></center>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                          <h1 class="small text-white stretched-link" href="#">Jumlah</h1>
                          <h1 class="small text-white" href="#"><?php echo $jumlahVendor ?></h1>
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-6 col-md-6">
                      <div class="card bg-secondary text-white mb-4">
                        <center><div class="card-body"><i class="fas fa-bullhorn fa-3x"></i><br>&nbsp;Jumlah Produk</div></center>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                          <h1 class="small text-white stretched-link" href="#">Jumlah</h1>
                          <h1 class="small text-white" href="#"><?php echo $jumlahProduk ?></h1>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div> --> 
              <div class="card-body">
                <div class="row">
                  <div class="col-lg-6">



                  </div>
                </div>
              </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
              <div class="container-fluid px-4">
                <div class="d-flex align-items-center justify-content-between small">
                  <div class="text-muted">Copyright &copy; Progress Akses Gate 2023</div>
                  <div>
                    
                  </div>
                </div>
              </div>
            </footer>
          </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo base_url();?>assets/js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo base_url();?>assets/assets/demo/chart-area-demo.js"></script>
        <script src="<?php echo base_url();?>assets/assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="<?php echo base_url();?>assets/js/datatables-simple-demo.js"></script>
      </body>
      </html>

      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
         <form action="<?php echo site_url('Admin/crud_konten'); ?>" method="post" role="form" enctype="multipart/form-data">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tambah data</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3">
                <label for="recipient-name" class="col-form-label">Nama:</label>
                <input type="text" name="nama" class="form-control" id="recipient-name">
              </div>
              <div class="mb-3">
                <label for="message-text" class="col-form-label">Alamat:</label>
                <textarea class="form-control" name="alamat" id="message-text"></textarea>
              </div>
              <div class="mb-3">
               <label class="control-label">Kategori: </label>
               <select style="height:35px" class="form-control" name="kategori" id="" type="text">
                <option value="">Pilih Kategori</option>
                <option value="pariwisata">Pariwisata</option>
                <option value="budaya">Seni Budaya</option>
              </select>
            </div>
            <div class="mb-3">
             <label for="file">Foto</label>
             <input style="width:200px" type="file" name="foto" class="form-control-file" required>
           </div>
           <div class="mb-3">
             <label for="message-text" class="col-form-label">Keterangan:</label>
             <textarea class="form-control" name="keterangan"></textarea>
           </div>
         </div>
         <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Send message</button>

        </div>
      </form>
    </div>
  </div>
</div>
